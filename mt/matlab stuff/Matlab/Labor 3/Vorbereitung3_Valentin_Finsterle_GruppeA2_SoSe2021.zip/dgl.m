%Valentin Finsterle, Gruppe A, 03.05.2021
function ypunkt = dgl(t)

    ypunkt = exp(-1.*t);

end