%Valentin Finsterle Gruppe A2 20/03/2021
clear;
z1=3+1i;
z2=-1+2i;

a=z1/(z2^2);

b=(z1+z2)^(1/4);

arg=atand((imag(b)/real(b)));
betr=sqrt(imag(b)^2+real(b)^2);

z3= betr*exp(1i*arg);

disp(sprintf('Das Ergebnis von a: %d + %d*i', real(a),imag(a)));
disp(sprintf('Das Ergebnis von b: %d + e^%d*i', betr, arg));