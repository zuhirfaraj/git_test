%Valentin Finsterle Gruppe A2 20/03/2021
function s = weg(t, a)

s=(1/2).*a.*t.^2;

end