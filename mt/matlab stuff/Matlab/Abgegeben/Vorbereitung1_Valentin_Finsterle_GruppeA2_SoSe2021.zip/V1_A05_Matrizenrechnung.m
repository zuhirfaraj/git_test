%Valentin Finsterle Gruppe A2 20/03/2021
A=[ 1 2; 3 -1; 2 4];

B=[-2 1; 0 3; -1 2];

C=[ 3 0 1; -2 1 4; 2 1 -1];

D=A'*B
E=B'*A
F=A*B'
G=B*A'
H=F*C
J=C*F

%D und E haben die gleiche Anzahl an Spalten und Zeilen, das Selbe gilt für
%F und G