#pragma once
#include <vector>
#include "Medikament.h"

class Medikamentenverzeichnis
{
	static std::vector<Medikament> liste;
public:
	static Medikament* Suche(int pzn);

private:
	static void ErzeugeListe();
};

