#include "Medikamentenplan.h"
#include <iostream>
#include "Medikamentenverzeichnis.h"

using namespace std;

Verabreichung::Verabreichung(): dosis{0,0,0,0}
{
	medikament = nullptr;
}

Verabreichung::Verabreichung(Medikament* medk, double menge[4]):medikament(medk)
{
	std::copy(menge, menge + 4, dosis);
}

void Verabreichung::Ausgeben() const
{
	cout << "Medikament:\t" << medikament->pr�paratname << "\t" << dosis[0] << "-" << dosis[1] << "-" << dosis[2] << "-" << dosis[3] << endl;
}

void Verabreichung::Info(int& pzn, std::string& hersteller, std::string& praeparat, double menge[4]) const
{
	pzn = medikament->PZN;
	hersteller = medikament->hersteller;
	praeparat = medikament->pr�paratname;
	std::copy(dosis, dosis + 4, menge);
}

std::istream& operator>>(std::istream& is, Verabreichung& v)
{
	int pzn;
	std::string h, pr;
	is >> pzn >> v.dosis[0] >> v.dosis[1] >> v.dosis[2] >> v.dosis[3];
	v.medikament = Medikamentenverzeichnis::Suche(pzn);
	return is;
}

std::ostream& operator<<(std::ostream& os, const Verabreichung& v)
{
	int pzn;
	std::string hersteller, praeparat;
	v.medikament->Info(pzn, hersteller, praeparat);
	os <<  pzn <<" " << v.dosis[0] << " " << v.dosis[1] << " " << v.dosis[2] << " " << v.dosis[3] << endl;
	return os;
}

//void Medikamentenplan::Hinzuf�gen(const Verabreichung& v)
//{
//	liste.push_back(v);
//}
//
//const std::vector<Verabreichung>& Medikamentenplan::Liste() const
//{
//	return liste;
//}
//
//std::istream& operator>>(std::istream& is, Medikamentenplan& plan)
//{
//	int size;
//	is >> size;
//	for(int i=0; i<size; i++)
//	{
//		Verabreichung v;
//		is >> v;
//		plan.liste.push_back(v);
//	}
//	return is;
//}
//
//std::ostream& operator<<(std::ostream& os, const Medikamentenplan& plan)
//{
//	os << plan.liste.size() << endl;
//	for(int i=0; i<plan.liste.size(); i++)
//	{
//		os << plan.liste[i];
//	}
//	return os;
//}

