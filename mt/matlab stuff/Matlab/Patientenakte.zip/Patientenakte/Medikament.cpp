#include "Medikament.h"
#include <iostream>

Medikament::Medikament(int PZN, std::string hersteller, std::string pr�paratname)
{
	this->PZN = PZN;
	this->hersteller = hersteller;
	this->pr�paratname = pr�paratname;
}

void Medikament::Ausgeben()
{
	std::cout << PZN << "\t" << hersteller << "\t" << pr�paratname << std::endl;
}

void Medikament::Info(int& PZN, std::string& hersteller, std::string& pr�paratname) const
{
	PZN = this->PZN;
	hersteller = this->hersteller;
	pr�paratname = this->pr�paratname;
}
