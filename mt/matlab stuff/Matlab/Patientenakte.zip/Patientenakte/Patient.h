#pragma once
#include <vector>
#include <string>
#include "Fall.h"
#include "Person.h"

/*
 * Verwaltet alle Daten eines Patienten
 */

class Angehoeriger :public Person
{
public:
	Angehoeriger();
	Angehoeriger(std::string vn, std::string nn, std::string adr);
	~Angehoeriger();
};

class Patient : public Person
{
	//Nr.4 Variable angehoeriger der Klasse Angeh�riger
	Angehoeriger angehoeriger;//Aggregation mit Pointer, wenn keiner da NULL

	std::vector<Fall> faelle;
	
	//Stammdaten
	int pid; //Patientenidentifikationsnummer

	//erzeugt eine neue PID
	void CreatePID();

public:
	Patient();
	Patient(std::string vn, std::string nn, std::string adr);

	//zugriff auf PID
	int PID() const { return pid; }

	static Patient ErzeugeTestPatienten();

	void HinzufuegenFall(Fall& f);
	void Ausgeben();

	//laden und speichern des Patienten
	bool Laden(const std::string ordner, int pid);
	bool Speichern(const std::string ordner);


	//Hilfsfunktionen
	std::string ErzeugeDateipfad(const std::string ordner, int pid) const;

	//Nr.4
	//void CreateAngehoeriger();
};

 