#pragma once
#include <string>

class Verabreichung;

class Medikament
{
	int PZN; // Pharmazentralnummer
	std::string hersteller;
	std::string pr�paratname;

	friend class Verabreichung;
public:
	Medikament(int PZN=0, std::string hersteller="", std::string pr�paratname="");
	void Ausgeben();

	void Info(int& PZN, std::string& hersteller, std::string& pr�paratname) const;
};

