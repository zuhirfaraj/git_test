#pragma once
#include <sstream>

class Datum
{
	unsigned char tag;
	unsigned char monat;
	unsigned short jahr;
public:
	Datum();
	Datum(unsigned char tag, unsigned char monat, unsigned short jahr);
	Datum(std::string datumAsString);

	std::string ToString() const;
	operator std::string() const;

	unsigned char Tag() const { return tag; }
	unsigned char Monat() const { return monat; }
	unsigned short Jahr() const { return jahr; }
};

