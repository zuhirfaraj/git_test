#pragma once
#include <string>

class Person
{
protected:
	std::string vorname;
	std::string nachname;
	std::string adresse;
public:
	Person(std::string vorname, std::string nachname, std::string adr);

	void Info(std::string& vorname, std::string& nachname, std::string& adresse);
	void SetzeName(std::string vorname, std::string nachname);
	void SetzeAdresse(std::string adresse);
};

