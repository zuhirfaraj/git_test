#include "Patient.h"
#include <iostream>
#include <fstream>
#include "Medikamentenverzeichnis.h"

using namespace std;

Angehoeriger::Angehoeriger() :Person("", "", "")
{

}

Angehoeriger::Angehoeriger(std::string vn, std::string nn, std::string adr) : Person(vn, nn, adr)
{

}

Angehoeriger::~Angehoeriger()
{

}

Patient::Patient() : Person("", "", "") 
{
	CreatePID();
}

Patient::Patient(std::string vn, std::string nn, std::string adr) : Person(vn, nn, adr)
{
	CreatePID();
}

void Patient::CreatePID()
{
	static int id = 1001;
	id++;
	pid = id;
}

Patient Patient::ErzeugeTestPatienten()
{
	std::string wohnadresse = "Tiefenbronnerstr. 65, 75175 Pforzheim";
	Patient pat("John", "Klein", wohnadresse);

	Fall fall(Datum(15, 7, 2017), "KH-Beh-vollstationaer", "E11.21");
	fall.BehandlungHinzufuegen(Behandlung(Datum(11, 12, 2015), "8-894.1")); //Multimodale Komplexbehandlung

	Medikament* med1 = Medikamentenverzeichnis::Suche(1692448);
	double dosis1[4] = { 0.5,0,0,0 };
	Verabreichung verabreichung1(med1, dosis1);
	fall.VerabreichungHinzufuegen(verabreichung1);
	Medikament* med2 = Medikamentenverzeichnis::Suche(1830229);
	double dosis2[4] = { 0,0,1,0 };
	Verabreichung verabreichung2(med2, dosis2);
	fall.VerabreichungHinzufuegen(verabreichung2);
	//pat.HinzufuegenFall(fall);

	//TODO Aufgabe 2 hier einf�gen
	Medikament* med3 = Medikamentenverzeichnis::Suche(939510);
	double dosis3[4] = { 1,0,0,0 };
	Verabreichung verabreichung3(med3, dosis3);
	fall.VerabreichungHinzufuegen(verabreichung3);
	pat.HinzufuegenFall(fall);

	//TODO Aufgabe 4 hier einf�gen 
	pat.angehoeriger.SetzeName("Marie", "Klein");
	pat.angehoeriger.SetzeAdresse(wohnadresse);

	return pat;
}

void Patient::HinzufuegenFall(Fall& f)
{
	faelle.push_back(f);
}

void Patient::Ausgeben()
{
	string vn, nn, adr;
	Info(vn, nn, adr);

	string vna, nna, adra;
	angehoeriger.Info(vna, nna, adra);

	cout << "=== PATIENT ====\nPID: " << pid << "\t" << vn << " " << nn << endl;
	cout << "Wohnadresse:\t" << adr << endl;
	
	for (Fall fall : faelle)
	{
		fall.Ausgeben();
	}

	cout << "Angehoeriger\n";
	cout << "\t" << vna << " " << nna << endl;
	cout << "\t" << adra << endl;
	
}

std::string Patient::ErzeugeDateipfad(const std::string ordner, int pid) const
{
	std::string pfad = ordner + "\\";
	pfad += std::to_string(pid) + ".txt"; //C++11
	return pfad;
}

bool Patient::Speichern(const std::string ordner)
{
	string fn = ErzeugeDateipfad(ordner, pid);
	ofstream out(fn);
	if (out.is_open())
	{
		string vn, nn, adr;
		Info(vn, nn, adr);
		out << pid <<"\t"<< vn <<"\t"<< nn <<"\t"<< adr << endl;

		string vna, nna, adra;//Parrallel zu oben
		angehoeriger.Info(vna, nna, adra);
		out << vna << " " << nna << " " << adra << endl;

		//F�lle
		for(int i=0; i<faelle.size();i++)
		{
			Fall f = faelle[i];
			out << f;
		}

		return true;
	}
	return false;

}

bool Patient::Laden(const std::string ordner, int pid)
{
	char buffer[120];
	ifstream in(ErzeugeDateipfad(ordner, pid));
	if (in.is_open())
	{
		std::string line;
		std::getline(in, line);

		istringstream ss(line);
		vector<string> vec;
		while (ss.getline(buffer, sizeof(buffer), '\t')) 
			vec.push_back(buffer);


		this->pid = std::stoi(vec[0]);
		SetzeName(vec[1], vec[2]);
		SetzeAdresse(vec[3]);

		std::string vna, nna, adra;
		in >> vna >> nna;
		getline(in, adra);//Weil Adresse Leerzeichen beinhaltelt, in >> geht nur bis zu einem Leerzeichen
		angehoeriger.SetzeName(vna, nna);
		angehoeriger.SetzeAdresse(adra);

		//F�lle
		Fall fall;
		while (in >> fall)
		{
			faelle.push_back(fall);
			fall = Fall(); // Fall Objekt leeren
		}
		return true;
	}
	return false;
}
