#include "Person.h"

Person::Person(std::string vorname, std::string nachname, std::string adresse)
{
	this->vorname = vorname;
	this->nachname = nachname;
	this->adresse = adresse;
}

void Person::Info(std::string& vorname, std::string& nachname, std::string& adresse)
{
	vorname=this->vorname;
	nachname = this->nachname;
	adresse=this->adresse;
}

void Person::SetzeName(std::string vorname, std::string nachname)
{
	this->vorname = vorname;
	this->nachname = nachname;

}

void Person::SetzeAdresse(std::string adresse)
{
	this->adresse = adresse;
}

