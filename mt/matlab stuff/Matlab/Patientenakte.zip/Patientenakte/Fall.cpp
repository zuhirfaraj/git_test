#include "Fall.h"
#include <iostream>

#include "Behandlungen.h"
#include "DatenListe.h"

using namespace std;

Fall::Fall()
{
}

Fall::Fall(Datum datum, std::string grund, std::string icd):aufnahmedatum(datum)
{
	aufnahmegrund = grund;
	this->icd = icd;
	static int i = 10000;
	fallnummer = i++;
}

//AUFGABE: Der Medikamentenplan sollte f�r die Ausgabe verantwortlich sein. Verschieben Sie den Code
//zur Ausgabe in die klasse Medikamentenplan und rufen Sie die entsprechende Methode hier stattdessen auf
void Fall::VerabreichungenAusgeben()
{
	cout << "\nMEDIKAMENTENPLAN\n";
	for (size_t i = 0; i < medikamentenplan.Liste().size(); i++)
	{
		medikamentenplan.Liste()[i].Ausgeben();
	}
}

void Fall::VerabreichungHinzufuegen(const Verabreichung& verabreichung)
{
	medikamentenplan.Hinzuf�gen(verabreichung);
}

void Fall::BehandlungenAusgeben() const
{
	cout << "\nBEHANDLUNGEN\n";
	for (size_t i = 0; i < behandlungen.Liste().size(); i++)
	{
		behandlungen.Liste()[i].Ausgeben();
	}
}

void Fall::BehandlungHinzufuegen(const Behandlung& behandlung)
{
	behandlungen.Hinzuf�gen(behandlung);
}

void Fall::Ausgeben()
{
	cout << "\nFALL: " << fallnummer << endl;
	BehandlungenAusgeben();
	VerabreichungenAusgeben();
}


std::ostream& operator<<(std::ostream& os, const Fall& fall)
{
	os << fall.fallnummer << " "<< (string)fall.aufnahmedatum <<" "<< fall.aufnahmegrund <<" "<< fall.icd << endl;
	os << fall.medikamentenplan;
	os << fall.behandlungen;
	return os;
}

std::istream& operator>>(std::istream& os, Fall& fall)
{
	string sdatum;
	os >> fall.fallnummer >> sdatum >> fall.aufnahmegrund >> fall.icd;
	fall.aufnahmedatum = sdatum;

	os >> fall.medikamentenplan;
	os >> fall.behandlungen;
	return os;
}
