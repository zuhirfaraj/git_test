#pragma once
#include <string>
#include "Medikamentenplan.h"
#include "Behandlungen.h"
#include "Datum.h"

//Nr.5
#include "DatenListe.h"

class Fall
{
	int fallnummer;
	Datum aufnahmedatum;
	std::string aufnahmegrund;
	std::string icd; //Diagnoseschl�ssel

	//Nr.5
	typedef DatenListe<Verabreichung> Medikamentenplan;

	Medikamentenplan medikamentenplan;
	Behandlungen behandlungen;
public:
	Fall();
	Fall(Datum datum, std::string grund, std::string icd);

	void VerabreichungenAusgeben();
	void VerabreichungHinzufuegen(const Verabreichung& verabreichung);

	void BehandlungenAusgeben() const;
	void BehandlungHinzufuegen(const Behandlung& beh);

	int Fallnummer() const { return fallnummer; }

	void Ausgeben();

	friend std::ostream& operator << (std::ostream& os, const Fall& fall);
	friend std::istream& operator >> (std::istream& os, Fall& fall);
};


