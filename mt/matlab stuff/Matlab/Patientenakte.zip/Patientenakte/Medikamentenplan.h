#pragma once
#include <vector>
#include <iostream>
#include "Medikament.h"

//Speichert Medikament mit Gabeinformation
class Verabreichung
{
	Medikament* medikament;
	double dosis[4];
public:
	Verabreichung();
	Verabreichung(Medikament* medk, double menge[4]);
	void Ausgeben() const;

	void Info(int& pzn, std::string& hersteller, std::string& pr�paratname, double menge[4]) const;
	friend std::istream& operator >>(std::istream& is, Verabreichung& v);
	friend std::ostream& operator <<(std::ostream& os, const Verabreichung& v);
};

//class Medikamentenplan
//{
//public:
//	void Hinzuf�gen(const Verabreichung& v);
//	const std::vector<Verabreichung>& Liste() const;
//
//private:
//	std::vector<Verabreichung> liste;
//
//	friend std::ostream& operator<<(std::ostream& os, const Medikamentenplan& m);
//	friend std::istream& operator>>(std::istream& is, Medikamentenplan& m);
//};

