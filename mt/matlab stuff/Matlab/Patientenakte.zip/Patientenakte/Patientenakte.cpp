// Patientenakte.cpp : Diese Datei enthält die Funktion "main". Hier beginnt und endet die Ausführung des Programms.
//

#include <iostream>
#include "Patient.h"
#include "Auswahlmenue.h"
#include <iostream>

using namespace std;

int main()
{
	const string repositoryPfad = ".\\Repository";

	int auswahl;
	while((auswahl = Auswahlmenue::AnzeigenUndBenutzerNachAuswahlFragen())!=0)
	{
		switch (auswahl)
		{
			case 1: //laden
			{
				int pid;
				cout << "Bitte geben Sie die PID des Patienten ein: \n";
				cin >> pid;
				Patient pat2;
				if (pat2.Laden(repositoryPfad, pid))
					pat2.Ausgeben();
				else
					cerr << "Kann Patienten mit dieser PID nicht finden.\n";
				system("pause");
			}
			break;
			
			case 2: //speichern
			{
				Patient pat = Patient::ErzeugeTestPatienten();
				pat.Speichern(repositoryPfad);
				cout << "Patient mit der PID " << pat.PID() << " wurde gespeichert.\n";
				system("pause");
			}
			break;
		}
	}
	return 0;
}
