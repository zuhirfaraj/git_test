#include "Datum.h"

Datum::Datum() : tag(0), monat(0), jahr(0)
{
}

Datum::Datum(unsigned char tag, unsigned char monat, unsigned short jahr)
{
	this->tag = tag;
	this->monat = monat;
	this->jahr = jahr;
}

Datum::Datum(std::string datumAlsString)
{
	std::string token;
	std::istringstream ss(datumAlsString);
	int i = 0;
	while (std::getline(ss, token, '.'))
	{
		if (i == 0) tag = std::stoi(token);
		if (i == 1) monat = std::stoi(token);
		if (i == 2) jahr = std::stoi(token);
		i++;
	}
}

std::string Datum::ToString() const
{
	std::stringstream buf;
	buf << (unsigned short)tag << "." << (unsigned short)monat << "." << jahr;
	return buf.str();
}

Datum::operator std::basic_string<char>() const
{
	return ToString();
}
