#pragma once

//verwaltet die Texte f�r das Auswahlmen�
class Auswahlmenue
{
public:
	static int AnzeigenUndBenutzerNachAuswahlFragen();
};

