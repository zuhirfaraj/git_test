#pragma once
#include <string>
#include <vector>
#include "Datum.h"

class Behandlung
{
	Datum datum;
	std::string operationenschluessel;

public:
	Behandlung(Datum dat, std::string operationenschluessel);
	void Ausgeben() const;

	std::string OPS() const { return operationenschluessel; } 
	Datum Behandlungsdatum() const { return datum; } 
};

class Behandlungen
{
public:
	void Hinzuf�gen(const Behandlung& d);
	const std::vector<Behandlung>& Liste() const;

private:
	std::vector<Behandlung> liste;

	friend std::istream& operator >>(std::istream& is, Behandlungen& b);
	friend std::ostream& operator <<(std::ostream& os, const Behandlungen& b);
};

