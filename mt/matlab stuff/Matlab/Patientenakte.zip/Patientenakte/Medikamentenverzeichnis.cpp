#include "Medikamentenverzeichnis.h"

std::vector<Medikament> Medikamentenverzeichnis::liste;

Medikament* Medikamentenverzeichnis::Suche(int pzn)
{
	//beim ersten Mal Liste erzeugen
	if (liste.empty())
		ErzeugeListe();

	for(size_t i=0; i<liste.size();i++)
	{
		int n;
		std::string x;
		liste[i].Info(n, x, x);
		if (pzn == n) 
			return &liste[i];
	}
	return nullptr;
}

void Medikamentenverzeichnis::ErzeugeListe()
{
	liste.push_back(Medikament(1692448, "Heumann", "Metformin"));
	liste.push_back(Medikament(1830229, "Hexal", "Cetirizin"));
	liste.push_back(Medikament(939510,"1A Pharma", "Pantoprazol"));
}
