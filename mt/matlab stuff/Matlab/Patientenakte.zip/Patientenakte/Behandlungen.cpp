#include "Behandlungen.h"
#include <iostream>

using namespace std;

void Behandlungen::Hinzuf�gen(const Behandlung& d)
{
	liste.push_back(d);
}

const std::vector<Behandlung>& Behandlungen::Liste() const
{
	return liste;
}

void Behandlung::Ausgeben() const
{
	cout << "Behandlung:\t" <<datum.ToString() << "\t" << operationenschluessel << endl;
}

Behandlung::Behandlung(Datum dat, std::string operationenschluessel):datum(dat)
{
	this->operationenschluessel = operationenschluessel;
}

//TODO Aufgabe 3 hier einf�gen
std::istream& operator>>(std::istream& is, Behandlungen& b)
{
		int size;//Schaut im Puffer wie viele Elemente es sind, Gr��e von der Liste mit size
		is >> size;
		for (int i = 0; i < size; i++)
		{
			string operationsschluessel;
			string datum;
			is >> operationsschluessel >> datum;//Liest aus dem Puffer die Werte
			Behandlung c(datum, operationsschluessel);
			b.liste.push_back(c);
		}
	return is;
}

std::ostream& operator<<(std::ostream& os, const Behandlungen& b)
{
	os << b.liste.size() << endl;//Auslesen von Gr��e der Liste, speichern im Puffer
	for(int i=0; i<b.liste.size();i++)
	{
		os << b.liste[i].OPS() << " " << (std::string) b.liste[i].Behandlungsdatum() << endl;
	}
	return os;

}
