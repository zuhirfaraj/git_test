#pragma once
#include <vector>
#include <iostream>

using namespace std;

template <typename T> class DatenListe
{
	public:
		void Hinzuf�gen(const T& param) 
		{
			liste.push_back(param);
		}

		const std::vector<T>& Liste(void) const
		{
			return liste;
		}
	private:
		std::vector<T> liste;

		friend std::istream& operator >>(std::istream& is, DatenListe& param)
		{
		int size;
		is >> size;
		for (int i = 0; i < size; i++)
		{
			T t;
			is >> t;
			param.liste.push_back(t);
		}
		return is;
		}

		friend std::ostream& operator <<(std::ostream& os, const DatenListe& param)
		{
		os << param.liste.size() << endl;
		for (int i = 0; i < param.liste.size(); i++)
		{
			os << param.liste[i];
		}
		return os;
		}
};