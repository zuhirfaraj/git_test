#include "Auswahlmenue.h"
#include <iostream>

using namespace std;

int Auswahlmenue::AnzeigenUndBenutzerNachAuswahlFragen()
{
	int auswahl=-1;
	while(auswahl<0 || auswahl>2)
	{
		system("cls");
		cout<<"Willkommen beim Krankenhausinformationssystem"<<endl;
		cout<<"---------------------------------------------"<<endl;
		cout<<"\t0: Beenden"<<endl;
		cout<<"\t1: Patient laden"<<endl;
		cout<<"\t2: Beispielpatient speichern"<<endl;
		cout<<"Was wollen Sie tun? ";
		cin>>auswahl;
	}	
	std::cin.clear();
	return auswahl;
}
